# Contributors

Name | GitHub user | Description | Role
--- | --- | --- | ---
Tiago Tresoldi | @tresoldi | patron | Other 
Johann-Mattis List | @LinguList | code, integration | Other
Robert Forkel | @xrotwang | code, integration | Other
Johannes Dellert | | editor | DataCurator, DataManager, Author
Pavel Sofroniev | @pavelsof | original team cdlf curation | DataCurator, DataManager
