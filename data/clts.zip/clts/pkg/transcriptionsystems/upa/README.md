# Uralic Phonetic Alphabet

This transcription system is used predominantly for the transcription and reconstruction of Uralic languages. It was first published in 1901 by Eemil Nestor Setälä.
