# Unified Transcription System of the GLD Project

This transcription system is used for all datasets submitted and published by the [Global Lexicostatistical Database](starling.rinet.ru/new100/UTS.htm) project.

